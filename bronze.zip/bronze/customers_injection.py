import dlt


# Expectations
customer_rules = {
    "rule_1" : "customer_id IS NOT NULL",
    "rule_2" : "region IS NOT NULL  ",
    "rule_3" : "customer_name IS NOT NULL"
}

#Injection Customers Data
@dlt.table(
    name="customer_stg"
)
@dlt.expect_all_or_drop(customer_rules)
def product_stg():
    df = spark.readStream.table("dlt_cdc_scd.source.customers")
    return df