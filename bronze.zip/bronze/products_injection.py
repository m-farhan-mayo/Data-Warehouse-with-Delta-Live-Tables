import dlt

# Expectations
product_rules = {
    "rule_1" : "product_id IS NOT NULL",
    "rule_2" : "price >= 0"
}

#Injection Products Data
@dlt.table(
    name="product_stg"
)
@dlt.expect_all_or_drop(product_rules)
def product_stg():
    df = spark.readStream.table("dlt_cdc_scd.source.products")
    return df