import dlt
from pyspark.sql.functions import *
from pyspark.sql.types import *

#Creating a MAT Business View

@dlt.table(
    name = "sales_business"
)

def sales_business():
    df_sales = spark.read.table("facts_sales")
    df_dimCust = spark.read.table("dim_customers")
    df_dimProd = spark.read.table("dim_products")

    df_join = df_sales.join(df_dimCust, df_sales.customer_id == df_dimCust.customer_id, "inner").join(df_dimProd, df_sales.product_id == df_dimProd.product_id, "inner")

    df_prun = df_join.select("region", "category", "Total_Sales")

    df_agg = df_prun.groupBy("region", "category").agg(sum("Total_Sales").alias("total_sales"))
    return df_agg